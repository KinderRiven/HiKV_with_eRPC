#pragma once
#ifndef MICA_COMMON_H_
#define MICA_COMMON_H_

#include <cstddef>
#include <cstdint>
#include <cinttypes>

#endif
