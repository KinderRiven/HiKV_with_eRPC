Tests for fabric transports.
