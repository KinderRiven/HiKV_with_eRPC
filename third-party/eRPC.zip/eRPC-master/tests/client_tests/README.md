End-to-end tests with an RPC client.
