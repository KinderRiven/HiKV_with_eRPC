Tests for eRPC components and utilities
