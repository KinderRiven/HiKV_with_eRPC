These scripts add firewalld rules for some ports commonly used in eRPC
development. Only `erpc_firewall.sh` is required; other scripts are optional.

These scripts have been tested on Fedora 27 and CentOS 7.5.
