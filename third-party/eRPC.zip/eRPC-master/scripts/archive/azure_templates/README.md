These scripts create one VM with two NICs (one with accelerated networking) and
tear it down.
