This contains old scripts that are rarely used anymore
