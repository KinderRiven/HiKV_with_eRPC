This is for bandwidth measurement between the two InfiniBand NICs on fawn-pluto1.

On this machine:
 * mlx5\_1 = ib1, NUMA node 0
 * mlx5\_3 = ib3, NUMA node 1
