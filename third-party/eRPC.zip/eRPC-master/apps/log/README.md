# Factors that affect performance:

* Some of these are hardcoded as static asserts
 * eRPC's congestion control
 * eRPC's small default request window size

* NIC DDIO should be enabled
