#!/bin/bash
sudo cp $(dirname $0)/src/.libs/libmlx5.so.1.0.0 /usr/lib/libmlx5.so.1.0.0
#sudo cp $(dirname $0)/src/.libs/*-rdmav2.so /usr/lib/libibverbs/
