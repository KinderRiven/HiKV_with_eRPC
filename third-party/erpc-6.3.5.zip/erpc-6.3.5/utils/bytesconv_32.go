// +build !amd64,!arm64,!ppc64

package utils

const (
	maxIntChars    = 9
	maxHexIntChars = 7
)
