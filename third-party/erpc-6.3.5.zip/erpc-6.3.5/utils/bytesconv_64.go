// +build amd64 arm64 ppc64

package utils

const (
	maxIntChars    = 18
	maxHexIntChars = 15
)
