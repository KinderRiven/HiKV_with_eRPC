namespace go codec
namespace perl codec
namespace py codec
namespace cpp codec
namespace rb codec
namespace java codec

struct ThriftEmpty {}
