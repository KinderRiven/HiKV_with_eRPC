namespace go thriftproto_test
namespace perl thriftproto_test
namespace py thriftproto_test
namespace cpp thriftproto_test
namespace rb thriftproto_test
namespace java thriftproto_test

struct test {
    1: string  author,
}