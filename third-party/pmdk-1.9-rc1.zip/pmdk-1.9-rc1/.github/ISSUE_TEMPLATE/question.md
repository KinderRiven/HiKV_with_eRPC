---
name: Question
about: Do you have question regarding PMDK? Don't hesitate to ask.
labels: "Type: Question"
---
# QUESTION: <!-- fill the title of question -->

## Details

<!-- fill this out -->

<!--
For questions and other non-bugs, you could use http://groups.google.com/group/pmem
You could also chat with members of the PMDK team real-time on the #pmem IRC channel on OFTC
-->
