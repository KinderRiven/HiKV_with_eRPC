This library has been moved to a
[separate repository](https://github.com/pmem/vmem).
