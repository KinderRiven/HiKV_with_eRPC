---
layout: manual
Content-Style: 'text/css'
title: _MP(DAXIO, 1)
collection: daxio
header: PMDK
date: daxio version 1.4
...

[comment]: <> (SPDX-License-Identifier: BSD-3-Clause)
[comment]: <> (Copyright 2018, Intel Corporation)

[comment]: <> (daxio.1 -- man page for daxio)

[NAME](#name)<br />
[SYNOPSIS](#synopsis)<br />
[DESCRIPTION](#description)<br />
[OPTIONS](#options)<br />
[EXAMPLE](#example)<br />
[SEE ALSO](#see-also)<br />

# NAME #

**daxio** - Perform I/O on Device DAX devices or zero a Device DAX device

# SYNOPSIS #

```
$ daxio [<options>]
```

# DESCRIPTION #

The daxio utility performs I/O on Device DAX devices or zero
a Device DAX device.  Since the standard I/O APIs (read/write) cannot be used
with Device DAX, data transfer is performed on a memory-mapped device.
The **daxio** may be used to dump Device DAX data to a file, restore data from
a backup copy, move/copy data to another device or to erase data from
a device.

There must be at least one Device DAX device involved either as the input
or output.  If input or output is not specified, it will default to stdin
or stdout respectively.

No length specified will default to input file/device length or to the
output file/device length, if input is a special char file or stdin.

For a Device DAX device, **daxio** will attempt to clear bad blocks within
the range of writes before performing the I/O (it can be turned off using
the '--clear-bad-blocks=no' option).

# OPTIONS #

`-i, --input`
Input device or file to read from.

`-o, --output`
Output device or file to write to.

`-z, --zero`
Zero the output device for *len* size, or the entire device if no
length was provided.  The output device must be a Device DAX device.

`-b, --clear-bad-blocks=<yes|no>`
Clear bad blocks within the range of writes before performing the I/O
(default: yes).

`-l, --len`
The length in bytes to perform the I/O.  To make passing in size easier
for kibi, mebi, gibi, and tebi bytes, *len* may include unit suffix.
The *len* format must be compliant with the format specified in IEC 80000-13,
IEEE 1541 or the Metric Interchange Format.  These standards accept SI units
with obligatory B - kB, MB, GB, ... (multiplier by 1000) suffixes,
and IEC units with optional "iB" - KiB, MiB, GiB, ..., K, M, G, ...
(multiplier by 1024) suffixes.

`-s, --seek`
The number of bytes to skip over on the output before performing a write.
The same suffixes are accepted as for *len*.

`-k, --skip`
The number of bytes to skip over on the input before performing a read.
The same suffixes are accepted as for *len*.

`-V, --version`

Prints the version of **daxio**.

`-h, --help`

Prints synopsis and list of options.

# EXAMPLE #

```
# daxio --zero /dev/dax1.0

# daxio --input=/dev/dax1.0 --output=/home/myfile --len=2M --seek=4096

# cat /dev/zero | daxio --output=/dev/dax1.0

# daxio --input=/dev/zero --output=/dev/dax1.0 --skip=4096
```

# SEE ALSO #

**daxctl**(1), **ndctl**(1)
and **<https://pmem.io>**
