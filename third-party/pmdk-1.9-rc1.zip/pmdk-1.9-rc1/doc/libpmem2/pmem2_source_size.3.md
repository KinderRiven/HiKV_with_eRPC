---
layout: manual
Content-Style: 'text/css'
title: _MP(PMEM2_SOURCE_SIZE, 3)
collection: libpmem2
header: PMDK
date: pmem2 API version 1.0
...

[comment]: <> (SPDX-License-Identifier: BSD-3-Clause)
[comment]: <> (Copyright 2019-2020, Intel Corporation)

[comment]: <> (pmem2_source_size.3 -- man page for pmem2_source_size)

[NAME](#name)<br />
[SYNOPSIS](#synopsis)<br />
[DESCRIPTION](#description)<br />
[RETURN VALUE](#return-value)<br />
[SEE ALSO](#see-also)<br />

# NAME #

**pmem2_source_size**() - returns the size of the data source

# SYNOPSIS #

```c
#include <libpmem2.h>

struct pmem2_source;
int pmem2_source_size(const struct pmem2_source *source, size_t *size);
```

# DESCRIPTION #

The **pmem2_source_size**() function retrieves the size of the file
in bytes pointed by file descriptor or handle stored in the *source* and puts
it in *\*size*.

This function is a portable replacement for OS-specific APIs.
On Linux, it hides the quirkiness of Device DAX size detection.

# RETURN VALUE #

The **pmem2_source_size**() function returns 0 on success.
If the function fails, the *\*size* variable is left unmodified, and one of
the following errors is returned:

On all systems:

* **PMEM2_E_INVALID_FILE_HANDLE** - source contains an invalid file handle.

On Windows:

* **PMEM2_E_INVALID_FILE_TYPE** - handle points to a resource that is not
a regular file.

On Linux:

* **PMEM2_E_INVALID_FILE_TYPE** - file descriptor points to a directory,
block device, pipe, or socket.

* **PMEM2_E_INVALID_FILE_TYPE** - file descriptor points to a character
device other than Device DAX.

* **PMEM2_E_INVALID_SIZE_FORMAT** - kernel query for Device DAX size
returned data in invalid format.

* -**errno** set by failing **fstat**(2), while trying to validate the file
descriptor.

* -**errno** set by failing **realpath**(3), while trying to determine whether
fd points to a Device DAX.

* -**errno** set by failing **open**(2), while trying to determine Device DAX's
size.

* -**errno** set by failing **read**(2), while trying to determine Device DAX's
size.

* -**errno** set by failing **strtoull**(3), while trying to determine
Device DAX's size.

On FreeBSD:

* **PMEM2_E_INVALID_FILE_TYPE** - file descriptor points to a directory,
block device, pipe, socket, or character device.

* -**errno** set by failing **fstat**(2), while trying to validate the file
descriptor.

# SEE ALSO #

**errno**(3),  **fstat**(2), **realpath**(3), **open**(2), **read**(2),
**strtoull**(3), **pmem2_config_new**(3), **libpmem2**(7)
and **<http://pmem.io>**
