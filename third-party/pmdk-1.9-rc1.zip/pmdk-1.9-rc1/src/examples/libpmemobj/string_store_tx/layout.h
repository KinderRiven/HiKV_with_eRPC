// SPDX-License-Identifier: BSD-3-Clause
/* Copyright 2015-2019, Intel Corporation */

/*
 * layout.h -- example from introduction part 2
 */

#define LAYOUT_NAME "intro_2"
#define MAX_BUF_LEN 10

struct my_root {
	char buf[MAX_BUF_LEN];
};
