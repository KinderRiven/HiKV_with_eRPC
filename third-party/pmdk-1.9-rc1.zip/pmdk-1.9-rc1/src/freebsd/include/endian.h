// SPDX-License-Identifier: BSD-3-Clause
/* Copyright 2017, Intel Corporation */

/*
 * endian.h -- redirect for FreeBSD <sys/endian.h>
 */

#include <sys/endian.h>
